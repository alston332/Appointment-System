<?php

return [
    'site_title' => 'Appointment System',
];
